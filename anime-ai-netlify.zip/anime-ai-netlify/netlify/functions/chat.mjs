export default async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  try {
    const { messages = [], mode = "Anime Assistant" } = await req.json();
    const key = Netlify.env.get("AI_API_KEY");
    const base = Netlify.env.get("AI_BASE_URL") || "https://api.openai.com/v1";
    const model = Netlify.env.get("AI_MODEL") || "gpt-4o-mini";
    if (!key) return Response.json({error:"AI_API_KEY has not been added in Netlify yet."},{status:500});
    const system = `You are Anime AI, a friendly anime-focused assistant. Mode: ${mode}. Help with anime discussions, original characters, worldbuilding, power systems, episode ideas, dialogue, and general questions. Keep responses appropriate for the user's age.`;
    const r = await fetch(`${base}/chat/completions`, {
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`},
      body:JSON.stringify({model,messages:[{role:"system",content:system},...messages],temperature:0.8})
    });
    const data=await r.json();
    if(!r.ok)return Response.json({error:data?.error?.message||"AI provider error"},{status:r.status});
    return Response.json({message:data?.choices?.[0]?.message?.content||"No response."});
  } catch(e){return Response.json({error:e.message||"Server error"},{status:500})}
};